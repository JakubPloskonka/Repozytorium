﻿// Kalkulator dla elektronikow
// Autor: Jakub Płoskonka
// Data ostatecznej wersji: 25.07.2023
// Cel: Program wykonuje konwersje liczb do różnych systemów liczbowych oraz działa jak kalkulator w części float.


#include <iostream>
#include <string>
#include<math.h>
#include <vector>


using std::cin;
using std::cout;
using std::string;
using std::vector;
using std::endl;
using std::pow;
using std::sqrt;


class Calculator
{                                                           //klasa bazowa
public:
    virtual ~Calculator() {}                                //destruktor wirtualny jest używany do zapewnienia usuwanięci pamięci dla obiektów, które są wskaźnikami na klasę bazową
    virtual void calculate() = 0;                           //metoda która jest dziedziczona w każdej klasie pochodnej
};

class DecCalculator : public Calculator
{
public:
    void calculate() override                               //klasa ta dziedziczy po klasie Calculator i przesłania (nadpisuje) metodę calculate() z klasy bazowej
    {
        string number;
        int base;

        cout << "Wpisz system liczbowy do przekonwertowania (16, 8, 2): ";
        cin >> base;

        cout << "Wpisz liczbe: ";
        cin >> number;

        int dec = Todec(number, base);

        cout << "Dziesietna wartosc: " << dec << endl;
    }

    int Todec(string number, int base) {                       //funkcja przeliczajaca systemy 16,8,2 na system dziesietny
        int result{};
        int d = number.length();
        for (int i = 0; i < d; i++) {
            int digit = number[d - 1 - i] - 48;
            if (digit <= 9)
                result += digit * pow(base, i);
            else result = result + (digit - 7) * pow(base, i); //dla systemu szesnastkowego trzeba przesunac sie o 55 w tabeli ASCI
        }
        return result;
    }
};

class BinaryCalculator : public Calculator
{
public:
    void calculate() override
    {
        cout << "Wpisz rodzaj konwersji:" << endl;
        cout << "1. Dec to Bin" << endl;
        cout << "2. Oct to Bin" << endl;
        cout << "3. Hex to Bin" << endl;


        int choice;
        cin >> choice;

        switch (choice)
        {
        case 1:                                             //wywołanie funkcji przeliczającej z systemu dziesiętnego na dwójkowy
        {
            int dec;
            cout << "Wpisz liczbe dziesietna: ";
            cin >> dec;
            cout << "Binarnie: " << decTobin(dec) << endl;
            break;
        }
        case 2:                                             //wywołanie funkcji przeliczającej z systemu ósemkowego na dwójkowy
        {
            int oct;
            cout << "Wpisz  liczbe osemkowa: ";
            cin >> oct;
            cout << "Binarnie: " << octToBin(oct) << endl;
            break;
        }
        case 3:                                             //wywołanie funkcji przeliczającej z systemu szesnastkowego na dwójkowy
        {
            string hex{};
            cout << "Wpisz liczbe szesnastkowa: ";
            cin >> hex;

            int decc = hex2dec(hex);                        // przeliczanie systemu szesnastkowego na dziesietny by potem przeliczyc z dziesietnego na binarny
            int bin = decTobin(decc);
            cout << "W systemie osemkowym: " << bin << endl;
            break;
        }
        default:
            cout << "Nieprawidlowy wybor." << endl;
            break;
        }
    }

private:
    long long decTobin(int n)
    {                                                       //funkcja zmienia system dziesiętny na binarny
        long long bin = 0;
        int rem, i = 1;

        while (n != 0)
        {
            rem = n % 2;
            n /= 2;
            bin += rem * i;
            i *= 10;
        }
        return bin;
    }

    int  octToBin(int oct)                                  // funkcja przeliczajaca system osemkowy na dwojkowy
    {
        int bin{};
        int decimalNumber = 0, i = 0;

        while (oct != 0)
        {
            decimalNumber += (oct % 10) * pow(8, i);
            ++i;
            oct /= 10;
        }

        i = 1;

        while (decimalNumber != 0)
        {
            bin += (decimalNumber % 2) * i;
            decimalNumber /= 2;
            i *= 10;
        }
        return bin;
    }

    int hex2dec(string hex)                                 //funkcja zmienia system szesnastkowy na dziesietny
    {
        int len = hex.size();
        int dec{}, index{};

        for (int i = len - 1; i >= 0; i--)
        {
            if (hex[i] >= '0' && hex[i] <= '9')
            {
                int digit = int(hex[i]) - 48;
                dec += digit * pow(16, index);
                index++;
            }
            else if (hex[i] >= 'A' && hex[i] <= 'F')
            {
                int digit = int(hex[i]) - 55;
                dec += digit * pow(16, index);
                index++;
            }
        }
        return dec;
    }
};

class OctalCalculator : public Calculator
{
public:
    void calculate() override
    {

        cout << "Wpisz rodzaj konwersji:" << endl;
        cout << "1. Dec to Octal" << endl;
        cout << "2. Bin to Octal" << endl;
        cout << "3. Hex to Octal" << endl;

        int choice;
        cin >> choice;
        switch (choice)
        {
        case 1:                                             // wywołanie funkcji przeliczającej z systemu dziesiętnego na ósemkowy
        {
            int dec;
            cout << "Wpisz liczbe dziesietna: ";
            cin >> dec;
            cout << "W systemie osemkowym: " << dec2octal(dec) << endl;
            break;
        }
        case 2:                                             //wywołanie funkcji przeliczającej z systemu dwójkowego na ósemkowy 
        {
            int bin{};
            cout << "Wpisz liczbe dwojkowa: ";
            cin >> bin;
            cout << "W systemie osemkowym: " << bin2octal(bin) << endl;
            break;
        }
        case 3:                                             //wywołanie dwóch funkcji przeliczających z systemu szesnastkowego na dziesiętnya potem z dziesiętnego na ósemkowy
        {
            string hex{};
            cout << "Wpisz liczbe szesnastkowa: ";
            cin >> hex;

            int decc = hex2dec(hex);                        // przeliczanie systemu szesnastkowego na dziesietny by potem przeliczyc z dziesietnego na osemkowy
            int octal = decTooctal(decc);
            cout << "W systemie osemkowym: " << octal << endl;
            break;
        }
        default:
            cout << "Nieprawidlowy wybor";
            break;
        }
    }

private:

    int dec2octal(int dec)                                  // funkcja przeliczajaca system dziesietny na osemkowy
    {
        int rem, i = 1, octalNumber = 0;
        while (dec != 0)
        {
            rem = dec % 8;
            dec /= 8;
            octalNumber += rem * i;
            i *= 10;
        }
        return octalNumber;
    }

    int bin2octal(long long bin)                            // funkcja przeliczajaca system dwojkowy na osemkowy
    {
        int octalNumber = 0, decimalNumber = 0, i = 0;

        while (bin != 0)
        {
            decimalNumber += (bin % 10) * pow(2, i);
            ++i;
            bin /= 10;
        }

        i = 1;

        while (decimalNumber != 0)
        {
            octalNumber += (decimalNumber % 8) * i;
            decimalNumber /= 8;
            i *= 10;
        }

        return octalNumber;
    }

    int hex2dec(string hex)                                 //funkcja zmienia system szesnastkowy na dziesietny
    {
        int len = hex.size();
        int dec{}, index{};

        for (int i = len - 1; i >= 0; i--)
        {
            if (hex[i] >= '0' && hex[i] <= '9')
            {
                int digit = int(hex[i]) - 48;
                dec += digit * pow(16, index);
                index++;
            }

            else if (hex[i] >= 'A' && hex[i] <= 'F')
            {
                int digit = int(hex[i]) - 55;
                dec += digit * pow(16, index);
                index++;
            }
        }
        return dec;
    }

    int decTooctal(int dec)                                 //funkcja zmienia system dziesietny na osemkowy
    {
        int rem, i = 1, octal = 0;
        while (dec != 0)
        {
            rem = dec % 8;
            dec /= 8;
            octal += rem * i;
            i *= 10;
        }
        return octal;
    }
};

class HexadecimalCalculator : public Calculator
{
public:
    void calculate() override
    {
        cout << "Wpisz rodzaj konwersji:" << endl;
        cout << "1. Dec to Hex" << endl;
        cout << "2. Bin to Hex" << endl;
        cout << "3. Octal to Hex" << endl;

        int choice;
        cin >> choice;
        switch (choice)
        {
        case 1:                                                             //wywołanie funkcji przeliczającej z systemu dziesiętnego na szesnastkowy
        {
            int dec_num{};
            cout << " Wpisz liczbe dziesietna: ";
            cin >> dec_num;
            cout << "W postaci szesnastkowej to: " << dec2hex(dec_num) << endl;
            break;
        }

        case 2:                                                             //wywołanie dwóch funkcji przeliczających z systemu dwójkowego na dziesietny a potem z dziesietnego na szesnastkowy
        {
            int bin;
            cout << "Wpisz liczbe binarna: ";
            cin >> bin;
            int dec = bin2dec(bin);                                         //przeliczanie z systemu dwojkowego na dziesietny by potem przeliczyc z dziesietnego na szesnastkowy
            string hex = dec2hex(dec);
            cout << "W postaci szesnastkowej to: " << hex << endl;
            break;
        }
        case 3:                                                             //wywołanie dwóch funkcji przeliczających z systemu osemkowego na dziesietny a potem z dziesietnego na szesnastkowy
        {
            int oct;
            cout << "Wpisz liczbe osemkowa: ";
            cin >> oct;
            int dec = oct2dec(oct);                                         //przeliczanie z systemu osemkowego na dziesietny by potem przeliczyc z dziesietnego na szesnastkowy
            string hex = dec2hex(dec);
            cout << "W postaci szesnastkowej to: " << hex << endl;
            break;
        }
        default:
            cout << "Nieprawidlowy wybor";
            break;
        }
    }

private:

    string dec2hex(int dec_num)                                             //funkcja przeliczajaca z systemu dziesietnego na szesnastkowy
    {
        int r{};
        string hex{};
        char num[] = { '0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F' };

        while (dec_num > 0)
        {
            r = dec_num % 16;
            hex = num[r] + hex;
            dec_num = dec_num / 16;
        }
        return hex;
    }

    int bin2dec(int bin)                                                    //funkcja przeliczajaca z systemu dwojkowego na dziesietny
    {
        int dec = 0, i = 0, rem;

        while (bin != 0)
        {
            rem = bin % 10;
            bin /= 10;
            dec += rem * pow(2, i);
            ++i;
        }
        return dec;
    }

    int oct2dec(int oct)                                                    //funkcja przeliczajaca z systemu osemkowego na dziesietny
    {
        int decimal{}, i{}, num;
        while (oct != 0)
        {
            num = oct % 10;
            oct /= 10;
            decimal += num * pow(8, i);
            ++i;
        }
        return decimal;
    }
};

class FloatingPointCalculator : public Calculator
{
public:
    void calculate() override
    {
        cout << "Wybierz operacje (wpisz cyfre):" << endl;
        cout << "1. Dodawanie" << endl;
        cout << "2. Odejmowanie" << endl;
        cout << "3. Mnozenie" << endl;
        cout << "4. Dzielenie" << endl;
        cout << "5. Potegowanie" << endl;
        cout << "6. Pierwiastkowanie" << endl;

        int choice;
        cin >> choice;
        switch (choice)
        {
        case 1:                                         //wywołanie funkcji sumującej
        {
            int numberOfNumbers;
            cout << "Wpisz ilosc liczb do dodania: ";
            cin >> numberOfNumbers;

            vector <double> numbers;
            for (int i = 0; i < numberOfNumbers; i++)        //petla dodajaca podane liczby do wektora "liczby"
            {
                double number;
                cout << "Wpisz liczbe:  " << i + 1 << ": ";
                cin >> number;
                numbers.push_back(number);
            }

            double suma = sum(numbers);
            cout << "Suma liczb: " << suma << endl;
            break;
        }

        case 2:                                         //wywołanie funkcji odejmującej
        {
            double a{}, b{};
            cout << "Wpisz liczbe: ";
            cin >> a;
            cout << "wpisz liczbe: ";
            cin >> b;

            double subtraction = sub(a, b);
            cout << "Roznica liczb: " << subtraction << endl;
            break;
        }

        case 3:                                         //wywołanie funkcji mnożącej
        {
            int numberOfNumbers{};
            cout << "Wpisz ilosc liczb do pomnozenia: ";
            cin >> numberOfNumbers;

            vector <double> numbers(numberOfNumbers);
            for (int i = 0; i < numberOfNumbers; ++i)
            {
                cout << "Wpisz liczbe " << i + 1 << ": ";
                cin >> numbers[i];
            }

            double result = multi(numbers);
            cout << "Wynik mnozenia: " << result << endl;
            break;
        }

        case 4:                                         //wywołanie funkcji dzielącej
        {
            double number1, number2;

            cout << "Wpisz liczbe: ";
            cin >> number1;

            cout << "Wpisz liczbe: ";
            cin >> number2;

            double result = division(number1, number2);
            cout << "Wynik : " << result << endl;
            break;
        }

        case 5:                                         //wywołanie funkcji potegującej 
        {

            double number;
            int potega;

            cout << "Wpisz liczbe: ";
            cin >> number;

            cout << "Wpisz potege: ";
            cin >> potega;

            double result = power(number, potega);
            cout << "Wynik: " << result << endl;
            break;
        }
        case 6:                                         //wywołanie funkcji pierwiatkującej
        {
            double number;

            cout << "Wpisz liczbe: ";
            cin >> number;

            double result = sqrt(number);
            cout << "Wynik: " << result << endl;
            break;
        }
        }
    }

private:

    double sum(vector <double> numbers)                  //funkcja sumująca
    {
        double sum = 0.0;
        for (const auto number : numbers)

            sum += number;

        return sum;
    }

    double sub(double number1, double number2)          //funkcja odejmująca
    {
        return number1 - number2;
    }

    double multi(vector<double> numbers)                 //funkcja mnożąca
    {
        double result = 1.0;
        for (const auto number : numbers)

            result = result * number;

        return result;
    }

    double division(double number1, double number2)     // funkcja dzieląca
    {
        if (number2 != 0)
            return number1 / number2;

        else
        {
            cout << "Dzielenie przez zero" << endl;
            return 0.0;
        }
    }

    double power(double number, int power)             // funkcja potegująca
    {
        return pow(number, power);
    }

    double sqrt(double number)                          // funkcja pierwiastkująca
    {
        return sqrt(number);
    }
};

class CalculatorFactory
{
public:
    Calculator* ourCalculator(string system)
    {
        if (system == "bin")
            return new BinaryCalculator();

        else if (system == "dec")
            return new DecCalculator();

        else if (system == "oct")
            return new OctalCalculator();

        else if (system == "hex")
            return new HexadecimalCalculator();

        else if (system == "float")
            return new FloatingPointCalculator();

        else
            return nullptr;

    }
};

int main()
{
    CalculatorFactory factory;
    string system;
    cout << "Wpisz system, w ktorym chcesz wykonac operacje (dec/bin/oct/hex/float): ";
    cin >> system;

    Calculator* calculator = factory.ourCalculator(system);
    if (calculator)
    {
        calculator->calculate();
        delete calculator;
    }
    else
        cout << "Nieprawidlowy system." << endl;

    return 0;
}
